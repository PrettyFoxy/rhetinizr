//(function ( $ ) {
//    $( document ).ready( function () {
////        if ( $('#js_block_border_core_news').length === 0 ) {
////            return false;
////        }
//        $.ajax( {
//            url: document.location.protocol
//            + '//ajax.googleapis.com/ajax/services/feed/load?v=1.0&num=10&callback=?&q='
//            + encodeURIComponent( 'http://www.rhetina.com/feed/' ),
//            dataType: 'json',
//            success: function ( data ) {
//                var $block = $( '<div />' ).addClass( 'block rhetinafeed' ),
//                    $block_title = '<div class="title js_sortable_header"><a href="http://www.rhetina.com/">Rhetina News</a></div>',
//                    $block_content = $( '<div />' ).addClass( 'content' ),
//                    $block_text = '';
//                $.each( data.entries, function ( i, entry ) {
//                    $block_text += '<div class="p_bottom_10">' +
//                        '<h6><a href="' + entry.link + '" target="_blank">' + entry.title + '</a></h6>' +
//                        '<div class="extra_info">' +
//                        entry.publishedDate +
//                        '</div>' +
//                        '<p>' + entry.contentSnippet + '</p>' +
//                        '</div>';
//                } );
//                $block_content.append( $block_text );
//                $block.append( $block_title ).append( $block_content );
//                $( '#js_block_border_core_news' ).before( $block );
//            }
//        } );
//    } );
//})( jQuery );