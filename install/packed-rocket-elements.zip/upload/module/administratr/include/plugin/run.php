<?php

if (!PHPFOX_IS_AJAX && Phpfox::isAdminPanel() && Phpfox::getParam('administratr.admin_theme') == 'administratr') {

    Phpfox::getLib('template')->setHeader('cache',
            array(
                'rhetina_touch.css' => 'style_css',
                'feed.js' => 'module_administratr'
            )
    );
}
