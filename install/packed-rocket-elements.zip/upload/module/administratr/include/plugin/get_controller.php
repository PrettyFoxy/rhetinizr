<?php

if ( !PHPFOX_IS_AJAX && Phpfox::isAdminPanel() ){
    $aTheme = Phpfox::getLib( 'database' )->select( 's.style_id, s.parent_id AS style_parent_id, s.folder AS style_folder_name, t.folder AS theme_folder_name, t.parent_id AS theme_parent_id, t.total_column, s.l_width, s.c_width, s.r_width' )
            ->from( Phpfox::getT( 'theme_style' ), 's' )
            ->join( Phpfox::getT( 'theme' ), 't', 't.folder = \'default\'' )
            ->where( 's.folder = \'default\'' )
            ->execute( 'getRow' );

    $aTheme['parent_style_folder'] = 'default';
    $aTheme['theme_folder_name'] = Phpfox::getParam('administratr.admin_theme');
    $aTheme['style_folder_name'] = Phpfox::getParam('administratr.admin_style');

    Phpfox::getLib( 'template' )->setStyle( $aTheme );
}