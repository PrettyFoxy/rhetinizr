{if $bHtml}
	{if isset($sName)}
	{phrase var='core.hello_name' name=$sName}
	{else}
	{phrase var='core.hello'}
	{/if},
	<br />
	<br />
	{$sMessage}
	<br />
	<br />
	{$sEmailSig}	
{else}	
	{if isset($sName)}
	{phrase var='core.hello_name' name=$sName}
	{else}
	{phrase var='core.hello'}
	{/if},
	{$sMessage}

	{$sEmailSig}	
{/if}